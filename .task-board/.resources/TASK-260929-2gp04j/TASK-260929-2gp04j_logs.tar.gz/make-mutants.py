from pathlib import Path
import difflib
import json
import subprocess

root = Path.cwd()
output = Path('/tmp/TASK-260929-2gp04j')
mutants = []
def mutate(name, file, before, after):
    original = (root / file).read_text()
    assert original.count(before) == 1, (name, original.count(before))
    changed = original.replace(before, after)
    formatted = subprocess.run(['rustfmt', '--edition', '2024', '--config-path', str(root / 'codex-rs/rustfmt.toml'), '--config', 'imports_granularity=Item', '--emit', 'stdout'], input=changed, text=True, capture_output=True)
    assert formatted.returncode == 0, (name, formatted.stderr)
    changed = formatted.stdout
    patch = ''.join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile='a/' + file, tofile='b/' + file))
    check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, text=True, capture_output=True)
    assert check.returncode == 0, (name, check.returncode, check.stderr)
    mutants.append({'name': name, 'patch': patch})
    print(f'{name}: git apply --check exit {check.returncode}')

tool = 'codex-rs/ext/goal/src/tool.rs'
runtime = 'codex-rs/ext/goal/src/runtime.rs'
activity = 'codex-rs/ext/goal/src/activity.rs'
extension = 'codex-rs/ext/goal/src/extension.rs'
api = 'codex-rs/ext/goal/src/api.rs'
mutate('create_waits_for_finish', tool,
'''            self.runtime
                .reconcile_live_activity(&permit)
                .await
                .map_err(FunctionCallError::RespondToModel)?;
            result''',
'''            if !matches!(self.kind, GoalToolKind::Create) {
                self.runtime
                    .reconcile_live_activity(&permit)
                    .await
                    .map_err(FunctionCallError::RespondToModel)?;
            }
            result''')
mutate('turn_start_requires_baseline', extension,
'''            let goal = {
                let permit =''',
'''            if input.token_usage_at_turn_start.is_none() {
                return;
            }
            let goal = {
                let permit =''')
mutate('resume_skips_budget_limited', runtime,
'''    pub async fn restore_after_resume(&self) -> Result<(), String> {
        let permit = self.goal_state_permit().await?;
        let goal = self.reconcile_live_activity(&permit).await?;''',
'''    pub async fn restore_after_resume(&self) -> Result<(), String> {
        let permit = self.goal_state_permit().await?;
        if self.inner.state_dbs.thread_goals().get_thread_goal(self.thread_id())
            .await.map_err(|err| err.to_string())?
            .is_some_and(|goal| goal.status == codex_state::ThreadGoalStatus::BudgetLimited)
        {
            return Ok(());
        }
        let goal = self.reconcile_live_activity(&permit).await?;''')
mutate('external_set_skips_budget_limited', runtime,
'''        let permit = self.goal_state_permit().await?;
        let committed = self.reconcile_live_activity(&permit).await?;
        if !self.is_enabled() {''',
'''        let permit = self.goal_state_permit().await?;
        if goal.status == codex_state::ThreadGoalStatus::BudgetLimited {
            return Ok(());
        }
        let committed = self.reconcile_live_activity(&permit).await?;
        if !self.is_enabled() {''')
mutate('complete_retains_sleep', activity,
'''                    ThreadGoalStatus::Active | ThreadGoalStatus::BudgetLimited''',
'''                    ThreadGoalStatus::Active | ThreadGoalStatus::BudgetLimited | ThreadGoalStatus::Complete''')
mutate('usage_limit_retains_sleep', activity,
'''                    ThreadGoalStatus::Active | ThreadGoalStatus::BudgetLimited''',
'''                    ThreadGoalStatus::Active | ThreadGoalStatus::BudgetLimited | ThreadGoalStatus::UsageLimited''')
mutate('budget_limited_admits_continuation', runtime,
'''        if goal.status != codex_state::ThreadGoalStatus::Active {
            self.inner.accounting_state.clear_active_goal();''',
'''        if !matches!(goal.status, codex_state::ThreadGoalStatus::Active | codex_state::ThreadGoalStatus::BudgetLimited) {
            self.inner.accounting_state.clear_active_goal();''')
mutate('disabled_clear_keeps_marker', api,
'''            // A committed clear revokes capability even while Goals is disabled.
            runtime.clear_activity(permit).await;''',
'''            // A committed clear revokes capability even while Goals is disabled.
            if runtime.is_enabled() {
                runtime.clear_activity(permit).await;
            }''')
mutate('disable_preserves_active_marker', runtime,
'''        self.inner.activity.set_enabled(enabled, store);''',
'''        if enabled || !store.get::<codex_extension_api::GoalActivity>()
            .is_some_and(|activity| activity.state == codex_extension_api::GoalActivityState::Active)
        {
            self.inner.activity.set_enabled(enabled, store);
        }''')
mutate('stop_preserves_active_marker', runtime,
'''        self.inner.activity.stop(store);''',
'''        if !store.get::<codex_extension_api::GoalActivity>()
            .is_some_and(|activity| activity.state == codex_extension_api::GoalActivityState::Active)
        {
            self.inner.activity.stop(store);
        }''')
mutate('timestamp_read_failure_keeps_known_marker', activity,
'''            Err(error) => {
                publication.revision += 1;''',
'''            Err(error) => {
                if error.contains("invalid unix timestamp millis") {
                    return Err(error);
                }
                publication.revision += 1;''')
mutate('cleared_revision_accepts_old_read', activity,
'''        if publication.revision != read_revision || publication.stopped || !publication.enabled {''',
'''        if (publication.revision != read_revision
            && !matches!(publication.goal, ReconciledGoal::Known(None)))
            || publication.stopped || !publication.enabled
        {''')
mutate('late_active_set_reinserts_cleared_goal', runtime,
'''        let Some(committed) = committed else {
            return Ok(());
        };''',
'''        let Some(committed) = committed else {
            if goal.status == codex_state::ThreadGoalStatus::Active
                && let Some(manager) = self.inner.thread_manager.upgrade()
                && let Ok(thread) = manager.get_thread(self.thread_id()).await
            {
                self.inner.activity.publish(thread.thread_extension_data(),
                    self.inner.activity.revision(), Ok(Some(goal)))?;
            }
            return Ok(());
        };''')
(output / 'TASK-260929-2gp04j_mutants.json').write_text(json.dumps(mutants, indent=2) + '\n')
print(f'{len(mutants)} narrowing mutants prepared; behavioral execution NOT RUN')
