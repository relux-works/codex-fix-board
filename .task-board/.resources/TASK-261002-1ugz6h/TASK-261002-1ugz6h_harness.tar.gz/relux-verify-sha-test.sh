#!/usr/bin/env bash
# Harness for the F2 "Verify the checked-out commit" gate (relux-ci.yml lines 60-66).
# Executes the gate's EXACT script (copied verbatim from the workflow) against
# accept/reject cases, then against a NARROWING mutant of the equality check.
# Usage: ./relux-verify-sha-test.sh <worktree>
set -u
cd "$1" || exit 2
HEAD_SHA="$(git rev-parse HEAD)"
PASS=0; FAIL=0

# --- exact gate body from relux-ci.yml lines 64-66 ---
gate() {
  [[ "$WANT_SHA" =~ ^[0-9a-f]{40}$ ]] || { echo "::error::sha must be a full 40-hex commit id, got '$WANT_SHA'"; exit 1; }
  HEAD_SHA_ACTUAL="$(git rev-parse HEAD)"
  [ "$HEAD_SHA_ACTUAL" = "$WANT_SHA" ] || { echo "::error::checked out $HEAD_SHA_ACTUAL, expected $WANT_SHA"; exit 1; }
}
# --- narrowing mutant M-sha-eq: exact equality weakened to prefix match ---
# Admits exactly one rejected class member: short-SHA prefixes of HEAD.
gate_mutant() {
  [[ "$WANT_SHA" =~ ^[0-9a-f]{40}$ ]] || { echo "::error::sha must be a full 40-hex commit id, got '$WANT_SHA'"; exit 1; }
  HEAD_SHA_ACTUAL="$(git rev-parse HEAD)"
  case "$HEAD_SHA_ACTUAL" in "$WANT_SHA"*) ;; *) echo "::error::checked out $HEAD_SHA_ACTUAL, expected $WANT_SHA"; exit 1; esac
}

check() { # name, want_exit, got_exit
  if [ "$2" = "$3" ]; then PASS=$((PASS+1)); echo "PASS: $1 (exit $3)";
  else FAIL=$((FAIL+1)); echo "FAIL: $1 (want exit $2, got $3)"; fi
}

# T1: full HEAD sha accepted
(WANT_SHA="$HEAD_SHA" gate) >/dev/null 2>&1; check "T1 valid full HEAD sha accepted" 0 $?
# T2: branch name rejected by the 40-hex regex
(WANT_SHA="relux/main" gate) >/dev/null 2>&1; check "T2 branch name rejected" 1 $?
# T3: wrong full sha rejected by the equality check
(WANT_SHA="0000000000000000000000000000000000000000" gate) >/dev/null 2>&1; check "T3 wrong full sha rejected" 1 $?
# T4: 7-hex prefix of HEAD rejected (40-hex required)
(WANT_SHA="${HEAD_SHA:0:7}" gate) >/dev/null 2>&1; check "T4 short-sha prefix rejected" 1 $?

# Mutant kill: T4 must FAIL on the mutant (mutant admits the prefix).
# NOTE: the mutant still enforces the 40-hex regex, so to isolate the equality
# weakening we drive the mutant's equality half directly with a 40-hex WANT that
# is a prefix-extension... impossible for equal-length strings. Instead the true
# narrowing pair is: mutant regex 7..40 + prefix equality. Use combined mutant:
gate_mutant_full() {
  [[ "$WANT_SHA" =~ ^[0-9a-f]{7,40}$ ]] || { echo "::error::sha must be hex, got '$WANT_SHA'"; exit 1; }
  HEAD_SHA_ACTUAL="$(git rev-parse HEAD)"
  case "$HEAD_SHA_ACTUAL" in "$WANT_SHA"*) ;; *) echo "::error::checked out $HEAD_SHA_ACTUAL, expected $WANT_SHA"; exit 1; esac
}
(WANT_SHA="${HEAD_SHA:0:7}" gate_mutant_full) >/dev/null 2>&1; m=$?
if [ "$m" = 0 ]; then echo "MUTANT-KILLED: T4 fails on M-sha-eq (exit 0, admits short prefix)"; PASS=$((PASS+1));
else echo "MUTANT-SURVIVED: T4 still rejects on M-sha-eq"; FAIL=$((FAIL+1)); fi
# Mutant must still reject a non-prefix short sha (narrowing, not deletion):
(WANT_SHA="deadbee" gate_mutant_full) >/dev/null 2>&1; check "M-sha-eq still rejects non-prefix hex" 1 $?

echo "verify-sha: pass=$PASS fail=$FAIL"
[ "$FAIL" = 0 ]
