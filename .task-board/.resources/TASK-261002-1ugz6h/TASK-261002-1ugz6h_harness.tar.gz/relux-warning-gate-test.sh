#!/usr/bin/env bash
# Harness for the F1 clippy warning-gate parser (relux-ci.yml lines 118-135).
# Executes the gate's EXACT parsing/filtering pipeline (lines 127-135, with the
# `just clippy ... | tee` step replaced by a fixture log) against accept/reject
# cases, then against narrowing mutants.
# Usage: ./relux-warning-gate-test.sh
set -u
T="$(mktemp -d)"; export RUNNER_TEMP="$T"
PASS=0; FAIL=0

KNOWN_WARNINGS='core/src/tools/registry.rs: warning: unused import: `crate::tools::context::ToolCallSource`
core/tests/suite/openai_file_mcp.rs: warning: unused import: `wiremock::matchers::body_json`
core/tests/suite/scenarios.rs: warning: unused import: `codex_protocol::openai_models::ReasoningEffort`'

# --- exact gate pipeline from relux-ci.yml lines 127-135 (takes $KNOWN_WARNINGS + $RUNNER_TEMP/clippy.log) ---
gate() {
  printf '%s\n' "$KNOWN_WARNINGS" | sed '/^$/d' > "$RUNNER_TEMP/known-warnings.txt"
  sed -E 's/\x1b\[[0-9;]*[A-Za-z]//g' "$RUNNER_TEMP/clippy.log" \
    | sed -nE 's/^([^ :]+):[0-9]+:[0-9]+: (warning: .*)$/\1: \2/p' | sort -u > "$RUNNER_TEMP/warnings.txt"
  new_warnings="$(grep -v -x -F -f "$RUNNER_TEMP/known-warnings.txt" "$RUNNER_TEMP/warnings.txt" || true)"
  echo "clippy warnings: $(wc -l < "$RUNNER_TEMP/warnings.txt") distinct, $(grep -c -x -F -f "$RUNNER_TEMP/known-warnings.txt" "$RUNNER_TEMP/warnings.txt" || true) of them upstream baseline"
  if [ -n "$new_warnings" ]; then
    printf '::error::clippy warnings outside the upstream baseline:\n%s\n' "$new_warnings"
    exit 1
  fi
}

check() { # name, want_exit, got_exit
  if [ "$2" = "$3" ]; then PASS=$((PASS+1)); echo "PASS: $1 (exit $3)";
  else FAIL=$((FAIL+1)); echo "FAIL: $1 (want exit $2, got $3)"; fi
}

ESC="$(printf '\x1b')"
# Fixture A: baseline-only log, WITH ANSI color codes (proves the strip works; c1ace00 matched nothing).
printf '%s\n' \
  "${ESC}[1m${ESC}[33mwarning${ESC}[0m${ESC}[1m: unused import: \`crate::tools::context::ToolCallSource\`${ESC}[0m" \
  "core/src/tools/registry.rs:12:5: warning: unused import: \`crate::tools::context::ToolCallSource\`" \
  "${ESC}[1mcore/tests/suite/openai_file_mcp.rs:8:5: warning: unused import: \`wiremock::matchers::body_json\`${ESC}[0m" \
  "core/tests/suite/scenarios.rs:44:5: warning: unused import: \`codex_protocol::openai_models::ReasoningEffort\`" \
  "Finished \`dev\` profile [unoptimized + debuginfo] target(s) in 1.23s" > "$T/clippy.log"
(gate) >"$T/outA.txt" 2>&1; check "W1 baseline-only log (colored) passes" 0 $?
grep -qE "clippy warnings: +3 distinct, +3 of them upstream baseline" "$T/outA.txt" \
  && { echo "PASS: W1 count line exact"; PASS=$((PASS+1)); } \
  || { echo "FAIL: W1 count line: $(cat "$T/outA.txt")"; FAIL=$((FAIL+1)); }

# Fixture B: baseline + one NEW warning (the hosted neg-1 shape).
cp "$T/clippy.log" "$T/clippyB.log"
printf '%s\n' "tools/src/lib.rs:4:5: warning: unused import: \`std::collections::HashMap as ReluxCiGateNegativeControl\`" >> "$T/clippyB.log"
cp "$T/clippyB.log" "$T/clippy.log"
(gate) >"$T/outB.txt" 2>&1; check "W2 new warning fails the gate" 1 $?
grep -q "tools/src/lib.rs: warning: unused import" "$T/outB.txt" \
  && { echo "PASS: W2 names the new warning file"; PASS=$((PASS+1)); } \
  || { echo "FAIL: W2 output: $(cat "$T/outB.txt")"; FAIL=$((FAIL+1)); }

# Narrowing mutant M-warn-allowlist: KNOWN_WARNINGS extended with exactly the new
# warning line -> W2 must FAIL (gate passes) while W-bogus still rejected.
KNOWN_WARNINGS_MUT="$KNOWN_WARNINGS
tools/src/lib.rs: warning: unused import: \`std::collections::HashMap as ReluxCiGateNegativeControl\`"
gate_mut() {
  printf '%s\n' "$KNOWN_WARNINGS_MUT" | sed '/^$/d' > "$RUNNER_TEMP/known-warnings.txt"
  sed -E 's/\x1b\[[0-9;]*[A-Za-z]//g' "$RUNNER_TEMP/clippy.log" \
    | sed -nE 's/^([^ :]+):[0-9]+:[0-9]+: (warning: .*)$/\1: \2/p' | sort -u > "$RUNNER_TEMP/warnings.txt"
  new_warnings="$(grep -v -x -F -f "$RUNNER_TEMP/known-warnings.txt" "$RUNNER_TEMP/warnings.txt" || true)"
  if [ -n "$new_warnings" ]; then exit 1; fi
}
cp "$T/clippyB.log" "$T/clippy.log"
(gate_mut) >/dev/null 2>&1; m=$?
if [ "$m" = 0 ]; then echo "MUTANT-KILLED: W2 fails on M-warn-allowlist (admits the new warning)"; PASS=$((PASS+1));
else echo "MUTANT-SURVIVED: W2 still fails on M-warn-allowlist"; FAIL=$((FAIL+1)); fi
printf '%s\n' "other/src/x.rs:1:1: warning: something else entirely" >> "$T/clippy.log"
(gate_mut) >/dev/null 2>&1; check "M-warn-allowlist still rejects other new warnings" 1 $?

# Token-preserving behavioral mutant M-no-strip: drop the ANSI-strip sed (the
# c1ace00 bug shape). The token "warning" is preserved; parsing behavior changes.
gate_nostrip() {
  printf '%s\n' "$KNOWN_WARNINGS" | sed '/^$/d' > "$RUNNER_TEMP/known-warnings.txt"
  sed -nE 's/^([^ :]+):[0-9]+:[0-9]+: (warning: .*)$/\1: \2/p' "$RUNNER_TEMP/clippy.log" | sort -u > "$RUNNER_TEMP/warnings.txt"
  new_warnings="$(grep -v -x -F -f "$RUNNER_TEMP/known-warnings.txt" "$RUNNER_TEMP/warnings.txt" || true)"
  if [ -n "$new_warnings" ]; then exit 1; fi
}
printf '%s\n' \
  "${ESC}[1mcore/tests/suite/openai_file_mcp.rs:8:5: warning: unused import: \`wiremock::matchers::body_json\`${ESC}[0m" \
  "core/src/tools/registry.rs:12:5: warning: unused import: \`crate::tools::context::ToolCallSource\`" \
  "core/tests/suite/scenarios.rs:44:5: warning: unused import: \`codex_protocol::openai_models::ReasoningEffort\`" > "$T/clippy.log"
(gate_nostrip) >/dev/null 2>&1; m=$?
if [ "$m" = 1 ]; then echo "MUTANT-KILLED: W1 fails on M-no-strip (colored baseline no longer matches)"; PASS=$((PASS+1));
else echo "MUTANT-SURVIVED: W1 still passes on M-no-strip"; FAIL=$((FAIL+1)); fi

echo "warning-gate: pass=$PASS fail=$FAIL"
rm -rf "$T"
[ "$FAIL" = 0 ]
