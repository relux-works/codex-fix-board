#!/usr/bin/env python3
"""Static checks for relux-ci.yml surface rows 1+2 (trigger/permission safety,
evidence exactness). Each check is named (S1..); mutants are file variants that
must fail exactly one named check. Usage:
  relux-static-checks.py <workflow-file>            # expect exit 0
  relux-static-checks.py <workflow-file> --mutant K # expect exit 1 naming check K
"""
import re, sys
import yaml

FAILURES = []

def check(name, cond, detail=""):
    print(("PASS" if cond else "FAIL") + f": {name}" + ("" if cond else f" -- {detail}"))
    if not cond:
        FAILURES.append(name)

def main(path):
    wf = yaml.safe_load(open(path))
    # S1: triggers are exactly workflow_dispatch + push on ci/relux-ci-selftest/**
    # (YAML 1.1 parses the `on:` key as boolean True.)
    on = wf.get("on", wf.get(True, {}))
    check("S1 triggers exact", set(on.keys()) == {"workflow_dispatch", "push"}, f"on={sorted(on.keys())}")
    check("S1b push branches", on.get("push", {}).get("branches") == ["ci/relux-ci-selftest/**"])
    check("S1c dispatch sha required", on.get("workflow_dispatch", {}).get("inputs", {}).get("sha", {}).get("required") is True)
    # S2: permissions contents: read, nothing else
    check("S2 permissions", wf.get("permissions") == {"contents": "read"}, f"permissions={wf.get('permissions')}")
    # S3: hosted runners only
    runs = [ (jn, j.get("runs-on")) for jn, j in wf.get("jobs", {}).items() ]
    check("S3 runs-on", all(r == "ubuntu-24.04" for _, r in runs), f"{runs}")
    # S4: every third-party uses: pinned by full 40-hex SHA
    sha_re = re.compile(r"^[^@]+@[0-9a-f]{40}(#.*)?$")
    unpinned = []
    for jn, j in wf.get("jobs", {}).items():
        for s in j.get("steps", []):
            u = s.get("uses", "")
            if u and not u.startswith("./") and not u.startswith("docker://"):
                if not sha_re.match(u):
                    unpinned.append(u)
    check("S4 third-party pins", not unpinned, f"unpinned={unpinned}")
    # S5: no secrets beyond the default token; no inputs/github interpolation into run:
    text = open(path).read()
    check("S5 no secrets", "secrets." not in text)
    interp_in_run = []
    for jn, j in wf.get("jobs", {}).items():
        for s in j.get("steps", []):
            run = s.get("run", "")
            if re.search(r"\$\{\{\s*(inputs|github)\.", run):
                interp_in_run.append(s.get("name", s.get("uses", "?")))
    check("S5b no expression in run:", not interp_in_run, f"{interp_in_run}")
    # S6: checkout ref is exactly inputs.sha || github.sha
    refs = [ s.get("with", {}).get("ref") for j in wf.get("jobs", {}).values()
             for s in j.get("steps", []) if "checkout" in s.get("uses", "")]
    check("S6 checkout ref", refs == ["${{ inputs.sha || github.sha }}"], f"refs={refs}")
    # S7: run-name carries the sha; concurrency is one group per exact sha
    check("S7 run-name sha", "inputs.sha || github.sha" in wf.get("run-name", ""))
    check("S7b concurrency", wf.get("concurrency", {}).get("group") == "relux-ci-${{ inputs.sha || github.sha }}",
          f"group={wf.get('concurrency', {}).get('group')}")
    # S8: failing suites fail their job (no masking on test steps).
    # `|| true` inside $(...) captures is fine (capture-only greps); only a
    # top-level `|| true` would mask the step exit.
    def strip_captures(run):
        return re.sub(r"\$\((?:[^()\"']|\"[^\"]*\")*\)", "", run)
    masked = []
    for jn, j in wf.get("jobs", {}).items():
        for s in j.get("steps", []):
            nm = s.get("name", "")
            if nm in ("Lint (fmt + clippy)", "Small crates tests", "codex-core tests", "codex-app-server tests"):
                if s.get("continue-on-error") or "|| true" in strip_captures(s.get("run", "")):
                    masked.append(nm)
    check("S8 no masking on test steps", not masked, f"masked={masked}")
    # S9: lane coverage markers (6 clippy crates; 4 small crates; helper bins; 3 zsh exclusions)
    clippy = next(s.get("run", "") for j in wf.get("jobs", {}).values() for s in j.get("steps", [])
                  if s.get("name") == "Lint (fmt + clippy)")
    for c in ["codex-tools", "codex-core", "codex-goal-extension", "codex-extension-api", "codex-app-server", "codex-rollout-trace"]:
        check(f"S9 clippy crate {c}", f"-p {c}" in clippy)
    small = next(s.get("run", "") for j in wf.get("jobs", {}).values() for s in j.get("steps", [])
                 if s.get("name") == "Small crates tests")
    for c in ["codex-tools", "codex-goal-extension", "codex-extension-api", "codex-rollout-trace"]:
        check(f"S9 small crate {c}", f"-p {c}" in small)
    core = next(s.get("run", "") for j in wf.get("jobs", {}).values() for s in j.get("steps", [])
                if s.get("name") == "codex-core tests")
    for t in ["shell_zsh_fork_skill_scripts_ignore_declared_permissions",
              "unified_exec_zsh_fork_guardian_reviews_persistent_terminal_in_current_turn",
              "unified_exec_zsh_fork_parent_approval_preserves_denied_reads"]:
        check(f"S9 core exclusion {t[:30]}..", t in core)
    print(f"static: failures={len(FAILURES)} {FAILURES if FAILURES else ''}")
    return 1 if FAILURES else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
