# TASK-260929-u2i5rr — receipt-state-machine, revision 6 build hold

HOLD-BUILD: the authoritative entry busy check printed `BUSY RUN-261002-b1a12a:TASK-260929-2gp04j:executing`. Following producer-brief tb-R58/tb-R64, this run writes tests without cargo/just, does not poll or wait, and does not hand off. Resume for the target guard, just fmt, just clippy -p codex-core, and publication when the authoritative script is FREE. No new runtime pass or mutant kill is claimed.

## Change and finding response

The reported repeat-of finding `resolve-initial-response-active-nonreserved-arm-unguarded` is addressed in `completion_receipt_late_initial_response_refuses_each_active_nonreserved_state`. It calls the legitimate owner's production `resolve_initial_response` with both Arm and InlineResult for each of Armed, Queued, and LeasedToSampling. Every call must return the precise InvalidTransition, preserve status, and leave the original exit claim sampleable with its original result. The narrowing mutant below exempts Armed only; the original refusal remains for Queued/Leased.

The error-arm sweep adds three further named tests, not product code:
- `completion_receipt_unqueued_and_mismatched_leases_preserve_active_state`: Reserved/Armed leasing refusal; fail/ack on Reserved/Armed/Queued; wrong-source lease fail/ack; publish_exit on Leased; legitimate lease/result preserved.
- `completion_receipt_unknown_id_is_refused_by_every_entry`: all seven ID/lease operations return UnknownReceipt, without changing an unrelated real lease.
- `completion_receipt_terminal_outcomes_refuse_every_late_operation`: all three terminal states refuse legitimate-owner resolve, exit, lease, fail, acknowledge, and repeated cancel, preserving the exact terminal outcome.
The existing `completion_receipt_poisoned_lock_returns_a_structured_error_after_panic` now checks all eight store entry points rather than reserve alone.

No product defect was exposed by execution in this run: execution is pending. The source implementation remains byte-identical to rev5. All 20 prior test names are retained; 24 tests now exist. Tests are left uncommitted for the managed Story snapshot; they are not described as committed tests.

## Scope and identities

Only the three authorized paths differ from the checkpoint: `codex-rs/core/src/unified_exec/mod.rs`, `completion_receipt.rs`, and `completion_receipt_tests.rs`. This rework edits only the test file. No out-of-scope lint edits, README, docs, dependencies, schemas, watchers, mailbox, or board files were edited. No commit/push/rebase/switch. The source has 469 nonblank/noncomment lines including the sibling test-module declaration (535 physical lines). macOS native Rust is the relevant local target; Linux/Windows are supported, no iOS target applies.

- `codex-rs/core/src/unified_exec/mod.rs`: SHA-256 `2db58da0345b3eee5fd26427692e2741803366830a85d3b96403d915efc97093`
- `codex-rs/core/src/unified_exec/completion_receipt.rs`: SHA-256 `0bb4312c83c60758045bd34dc5dab69c3bd28832b4544eec082751bb88716981`
- `codex-rs/core/src/unified_exec/completion_receipt_tests.rs`: SHA-256 `b89622b0811f618203d06384a2691e18dc5c383e11a3bbc6fdd8806d8a238317`

## AC coverage

**6 of 6 AC rows have named driving/refusal tests in the candidate; 0 of 6 AC rows driven in this run.** Prior hosted rev5 green evidence is attached on the board: exact tree 00518744e87f5bb1fa024ac3e2cdd903e6b0c5a8, run 36987452652, all lanes green and 20 receipt tests passing. Those test bytes differ from this candidate: no prior green is relabeled as a 24-test pass. Clippy is not test execution and was not run here.

| AC | Driving and refusal tests (names in legend) | Production call site in completion_receipt.rs |
|---|---|---|
| 1 | happy; second; terminal-late | reserve:274 → resolve_initial_response:302 → publish_exit:375 → lease_for_sampling:404 → acknowledge_sampled:464 |
| 2 | orders (barriers force early-inline, early-arm and arm-first); inline-wait; duplicate-reserved; late-initial | publish_exit:375; resolve_initial_response:302; lease_for_sampling:404 |
| 3 | retry; stale-fail; mismatch | fail_sampling:441; lease_for_sampling:404; acknowledge_sampled:464 |
| 4 | cancel-states; terminal-owner; terminal-late | cancel:492; lease_for_sampling:404; acknowledge_sampled:464; reserve:274 |
| 5 | capacity (64/65); history; owner-boundary | reserve:274; cancel:492; status:515; ReceiptOwner::new:34 |
| 6 | sources; claim-race; happy; mismatch | lease_for_sampling:404; fail_sampling:441; acknowledge_sampled:464; status:515 |

The inactive production API is the intended entry point for this leaf. It has no tool/mailbox call site by the explicit Description and Scope.

## Surface coverage map

| Surface row | Attacking tests | Killed narrowing mutants | Out-of-contract inputs (AC clause) |
|---|---|---|---|
| concurrency state machine | All 24 named tests; new late-initial, mismatch, unknown, terminal-late; expanded poison | No current-tree mutant execution. Historical M1/M2/M4/M7 kills are recorded in prior board evidence; new M17 Armed-only exception is mapped below, not claimed killed. This row remains runtime-unverified and blocks handoff in this run. | None within the supplied row. Tool launch, mailbox, transport, process-manager hooks and model wakes are excluded by Description “Not wired to tools or the mailbox yet” and Scope “no watcher/process-manager hooks”. |

Brief/reference gap: the installed project-management attack-surface catalog contains no `concurrency state machine` row, although the supplied surface-table names it. This report follows the supplied invariant/families in full; it does not silently replace the row or change shared skill infrastructure.

## Exhaustive error/transition-arm sweep

Line numbers below refer to the unchanged product file. Tests call production API methods, not a duplicate state-machine implementation. Aliases expand to exact names in the legend. Unreachable defensive arms and random-ID collision paths are explicitly bounded, not described as driven.

| Production branch or arm | Driving test / stated bound |
|---|---|
| new:40 empty call → InvalidOwner | owner-bounded |
| new:40 >256 bytes → InvalidOwner; nonempty <=256 → owner | owner-bounded, owner-boundary (256/257) |
| ReceiptPhase::status:200 Reserved (None or retained Some) | happy, duplicate-reserved |
| status:201 Armed / :202 Queued / :203 Leased | late-initial (all 3), happy |
| status:206 Inline / :207 Sampled / :208 Cancelled | orders, happy, cancel-states, terminal-late |
| ReceiptPhase::error:214–219 active-phase InvalidTransition | Unreachable through public API: only terminal_error calls this helper, and retire only receives terminal variants. No private-state forging to claim reachable coverage. |
| error:220 Inline → InvalidTransition | orders, terminal-late via every late operation |
| error:223 Sampled → AlreadyConsumed | second, terminal-late |
| error:224 Cancelled → Cancelled(reason) | cancel-states, terminal-late |
| terminal_error:245 foreign terminal owner → ForeignOwner | terminal-owner (thread, generation, call; six callers) |
| terminal_error:246 legitimate terminal → phase.error | terminal-late (all 3 outcomes; six callers) |
| terminal_error:247 absent terminal → UnknownReceipt | unknown (six callers); history proves expiration |
| retire:255 active remove absent → UnknownReceipt | Unreachable publicly: callers validate active presence under the same held store lock, and there is no intervening removal. Declared bound. |
| retire:257 full terminal history → pop oldest | history, 65 sequential retirements with latest 64 preserved |
| retire:260 push terminal, frees active slot | happy, orders, cancel-states, capacity, history |
| lock_state:270 poisoned lock → LockPoisoned | poison through all eight public store methods |
| reserve:276 full active capacity → CapacityExceeded | capacity |
| reserve:283–290 fresh UUID accepted, retry on active or terminal collision | Fresh branch: happy/capacity/history. Collision retry branch: unforced randomness, not driven; no injectable ID source is part of this inactive API. |
| reserve:292 exhausted 4 attempts → IdGenerationFailed | Unforced random UUID exhaustion, not driven. Retains structured error; no product change solely to add test hook. |
| reserve:293 insert Reserved(None) | happy |
| resolve:316 foreign active owner → ForeignOwner | foreign-resolve-lease |
| resolve:323 Reserved(Some)+Inline → Inline action | orders, duplicate-reserved |
| resolve:328 Reserved(None)+Inline → InvalidTransition(Reserved) | inline-wait |
| resolve:337 Reserved(Some)+Arm → Queued action | orders, duplicate-reserved |
| resolve:338 Reserved(None)+Arm → Armed action | happy, late-initial |
| resolve:341 active non-Reserved+either decision → InvalidTransition | late-initial (Armed/Queued/Leased × both decisions, unchanged state and outcome) |
| resolve:347 no active → terminal_error | terminal-owner, terminal-late, unknown |
| resolve:351 Inline action → retire InlineResult | orders, duplicate-reserved |
| resolve:355 Armed action → phase Armed | happy, late-initial |
| resolve:360 missing active after Armed action → UnknownReceipt | Unreachable publicly: earlier lookup succeeded under the same lock, with no removal between. |
| resolve:363 Queued action → phase Queued(retained exit) | orders, duplicate-reserved |
| resolve:368 missing active after Queued action → UnknownReceipt | Same lock/invariant as :360; unreachable publicly. |
| publish:383 foreign active owner → ForeignOwner | foreign-runtime |
| publish:385 missing active → terminal_error | terminal-owner, terminal-late, unknown |
| publish:389 Reserved with no completion → retain Some | orders, duplicate-reserved |
| publish:393 Armed → Queued | happy, orders |
| publish:397 active invalid phase → InvalidTransition | duplicate-reserved (Reserved(Some)), duplicate-exit (Queued), mismatch (Leased) |
| lease:412 foreign active owner → ForeignOwner | foreign-resolve-lease |
| lease:414 missing active → terminal_error | terminal-owner, terminal-late, unknown |
| lease:418 Queued → Leased with fresh token and source | happy, sources, retry |
| lease:433 Leased → AlreadyLeased | sources, claim-race |
| lease:434 other active phase → InvalidTransition | mismatch (Reserved, Armed) |
| fail:444 foreign active lease owner → ForeignOwner | foreign-lease |
| fail:446 missing active → terminal_error | terminal-owner, terminal-late, unknown |
| fail:454 matching token AND source → Queued(same result) | retry, stale-fail, sources |
| fail:459 nonleased or token/source mismatch → StaleLease | mismatch (Reserved/Armed/Queued/source); stale-fail (old token) |
| acknowledge:470 foreign active lease owner → ForeignOwner | foreign-lease |
| acknowledge:476 matching token AND source → completion | happy, sources, retry |
| acknowledge:477 nonleased or token/source mismatch → StaleLease | mismatch (Reserved/Armed/Queued/source); retry (old token) |
| acknowledge:479 absent active → terminal_error | terminal-owner, terminal-late, unknown |
| acknowledge:482 retire Sampled(source) | happy (Pushed), sources (Stdin), claim-race |
| cancel:500 foreign active owner → ForeignOwner | foreign-runtime |
| cancel:501 valid active → retire Cancelled(reason) at :511 | cancel-states (Reserved, Armed, Queued, Leased); reasons Released/OwnerStopped/Shutdown/Interrupted |
| cancel:504 unknown → UnknownReceipt | unknown |
| cancel:505 foreign terminal → ForeignOwner | terminal-owner |
| cancel:506 legitimate terminal → AlreadyTerminal | terminal-owner, terminal-late (all 3 terminal states) |
| status:522 foreign active → ForeignOwner; :523 valid active → phase.status | foreign-runtime; happy, late-initial |
| status:525 foreign terminal → ForeignOwner | terminal-owner (all 3 states × 3 foreign owner dimensions) |
| status:526 legitimate terminal → phase.status | terminal-owner, terminal-late, history |
| status:527 absent terminal → UnknownReceipt | unknown, history |

These bounds are not out-of-contract input refusals: they are internal arms whose failure cannot be induced through a valid public operation sequence without modifying RNG/invariants. Concurrent-order paths retain the existing barriers; this rework makes late-decision cases deterministic.

## Mutant table (recipes, not executions)

**0 new mutant executions, 0 observed new kills.** None of these unrun recipes is reported as a killed mutant. Under the assignment's no-named-failure rule they are unverified survivors for handoff purposes; the bound is the missing behavioral execution, not evidence that a weakened gate is safe. No mutant was applied to the candidate. Use a scratch copy for execution when hosted/reviewer infrastructure permits core tests; no local core tests are allowed by the latest producer brief.

| Mutant | What it narrows the gate to | Named test expected to fail | Execution / survivor bound |
|---|---|---|---|
| M17: in resolve's `(phase, _)` arm, return Action::Armed only if phase is Armed; otherwise keep original InvalidTransition | Admits exactly late decisions for Armed, retains refusals for Queued/Leased | completion_receipt_late_initial_response_refuses_each_active_nonreserved_state | Unrun; expected failing assertion not measured; late-Armed refusal runtime-unverified |
| Review mutant: replace the entire non-Reserved arm with Action::Armed | Also overwrites Queued/Leased with Armed and loses retained exit | Same test | Unrun; broader recipe retained only as review reproduction, M17 supplies narrowing |
| M18: ignore source match only when a forged lease says TerminalStdinOutput against a live PushedCompletion | Token check and other source refusals stay; one mismatch is admitted | completion_receipt_unqueued_and_mismatched_leases_preserve_active_state | Unrun; fail/ack source gates runtime-unverified |
| M1/M2 | Bypass owner comparison on active lease/resolve | completion_receipt_foreign_owner_is_refused_on_resolve_and_lease | Historical rev2 failures reported, no new execution |
| M4 | Admit stale failure after a newer lease exists | completion_receipt_stale_failed_lease_cannot_requeue_a_new_lease | Historical rev2 failure reported, no new execution |
| M7 | Admit duplicate exit only while Reserved(Some) | completion_receipt_duplicate_exit_while_reserved_preserves_first_completion | Historical rev2 failure reported, no new execution |
| M12/M13/M14 generation-only variants | Keep thread/call checks; admit foreign-generation terminal errors/status/cancel | completion_receipt_terminal_history_refuses_foreign_owners_and_repeat_cancellation | No new execution; runtime gate-kill evidence remains a review obligation |
| M15 narrowing 64→65 retention | Keeps eviction but allows exactly one extra retired handle | completion_receipt_terminal_history_evicts_only_the_oldest_after_64_outcomes | No new execution; retention kill unverified here |
| M16 source overwrite | Record PushedCompletion when TerminalStdinOutput owns the lease | completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease | No new execution; attribution kill unverified here |

## Test-name legend

| Alias | Exact test name |
|---|---|
| happy | `completion_receipt_happy_path_samples_exactly_once` |
| second | `completion_receipt_rejects_a_second_claim_after_sampling` |
| orders | `completion_receipt_exit_and_initial_response_are_linearized_in_both_orders` |
| inline-wait | `completion_receipt_inline_decision_waits_for_finalized_exit` |
| retry | `completion_receipt_failed_lease_requeues_same_receipt_and_rejects_stale_token` |
| stale-fail | `completion_receipt_stale_failed_lease_cannot_requeue_a_new_lease` |
| cancel-states | `completion_receipt_cancellation_is_terminal_from_each_unsampled_state` |
| capacity | `completion_receipt_capacity_refuses_the_65th_and_reuses_a_freed_slot` |
| history | `completion_receipt_terminal_history_evicts_only_the_oldest_after_64_outcomes` |
| terminal-owner | `completion_receipt_terminal_history_refuses_foreign_owners_and_repeat_cancellation` |
| foreign-runtime | `completion_receipt_foreign_runtime_generation_is_refused` |
| foreign-resolve-lease | `completion_receipt_foreign_owner_is_refused_on_resolve_and_lease` |
| foreign-lease | `completion_receipt_foreign_lease_is_refused_on_fail_and_acknowledge` |
| sources | `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease` |
| claim-race | `completion_receipt_terminal_stdin_and_pushed_claim_race_consumes_once` |
| duplicate-exit | `completion_receipt_refuses_duplicate_exit_publication` |
| duplicate-reserved | `completion_receipt_duplicate_exit_while_reserved_preserves_first_completion` |
| owner-bounded | `completion_receipt_owner_requires_a_bounded_call_id` |
| owner-boundary | `completion_receipt_owner_accepts_256_bytes_and_refuses_257` |
| late-initial | `completion_receipt_late_initial_response_refuses_each_active_nonreserved_state` |
| mismatch | `completion_receipt_unqueued_and_mismatched_leases_preserve_active_state` |
| unknown | `completion_receipt_unknown_id_is_refused_by_every_entry` |
| terminal-late | `completion_receipt_terminal_outcomes_refuse_every_late_operation` |
| poison | `completion_receipt_poisoned_lock_returns_a_structured_error_after_panic` |

## Commands and evidence honesty

| Command | Real exit | Result / artifact |
|---|---:|---|
| task-board m set_status(development) | 0 | Entered assigned role |
| busy-check entry (bundled shell call) | standalone status not captured; enclosing shell 2 | Printed authoritative BUSY. Git reads and an rg for missing codex-rs/justfile followed it; enclosing 2 is not claimed as the script's exit. No rerun/poll. |
| rustfmt --version | 0 | rustfmt-readiness-01.log |
| rustfmt --edition 2024 completion_receipt_tests.rs | 0 on each of 01/02/03 | rustfmt-01.log, -02.log, -03.log; direct formatter only, no cargo/just or target use |
| git diff --check | 0 | diff-check-01.log and -02.log |
| Python identity/test-name inventory | 0 | identity-01.log; 24 tests, product unchanged |
| just fmt; just fix -p codex-core; just clippy -p codex-core; target guard | NOT RUN | HOLD-BUILD. Prior fast-lane green is not reused for changed test bytes. Latest rev6 requires fmt/clippy; any later fix edits outside the 3 paths must be reverted. |
| just test -p codex-core -E 'test(completion_receipt)' and mutant suites | NOT RUN | Latest producer/rework brief forbids local core suites; hosted CI/reviewer execute candidate after handoff. |
| task-board handoff | NOT RUN | Hold required by authoritative BUSY; no validation/publication process left running. |

The initial resource projection mistakenly asked for unsupported `resources` (textual parse-error; standalone exit not captured in its mixed shell call); it was repaired with a task-scoped checklist read and resource CLI. Missing local skill directories/justfile probes were lookup failures, never treated as evidence of feature absence.

## Outcome-scoped logbook and next step

- Rev6 is tests-only rework of the repeated late-initial-response refusal class; all prior reviewer regression tests remain.
- Full branch sweep records real public paths and names the RNG/invariant defensive bounds rather than introducing mocks into product code.
- No direct control-root writes. This report and evidence archive are prepared outside the managed worktree only as the explicitly authorized outcome-artifact exception; attachment uses task-board APIs. Scratch remains in ignored task-scoped .temp.
- Busy is authoritative: another developer is building. This run does not attempt publication or validation and does not inspect other runs to override the script.
- Resume this leaf for build/typecheck and hosted validation. Checklist items tied to current test/compile/mutant green are left unchecked. Handoff preconditions are not asserted satisfied.
