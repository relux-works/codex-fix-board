# TASK-260929-u2i5rr — receipt-state-machine, revision 5

Producer: RUN-261002-5a24c9. Ready for review under the revision-5 fast-lane instructions. All five revision-4 finding classes are addressed by test changes; no product-code defect was found and no product code changed in this rework.

## Scope and candidate identity

The uncommitted candidate contains only `codex-rs/core/src/unified_exec/mod.rs`, `completion_receipt.rs`, and `completion_receipt_tests.rs`. The branch checkpoint remains `0462dcc062b822bb8fff16cc31ce6eeab69823b9`. No commit, branch switch, push, or control-root file edit was made.

Compared with the attached revision-4 patch, the rework adds 167 test lines, deletes no test lines, and retains all 17 prior test names. There are now 20 tests. `completion_receipt.rs` remains byte-identical to revision 4, SHA-256 `0bb4312c83c60758045bd34dc5dab69c3bd28832b4544eec082751bb88716981`; it has 469 nonblank, noncomment lines including its test-module declaration. Current tests SHA-256: `7f4f65c176045fa4ea153b568e23cad65eca6a81237a1704ae60568268940ac6`.

The three out-of-scope unused-import edits in `core/src/tools/registry.rs`, `core/tests/suite/openai_file_mcp.rs`, and `core/tests/suite/scenarios.rs` were restored to the checkpoint exactly as requested by the scope-fix instruction. No delta in these paths remains. No README, dependency, schema, CI, watcher, process-manager, or mailbox edits were made.

## Full rejected-finding set

| Finding | Named regression test / change | Production line guarded in completion_receipt.rs | Mutant mapping |
|---|---|---|---|
| terminal-history-bound-unguarded | New `completion_receipt_terminal_history_evicts_only_the_oldest_after_64_outcomes`: reserve/cancel 65 receipts sequentially; first is UnknownReceipt and every retained receipt, including the last, is Cancelled | `reserve`:274, `cancel`:492, `status`:515; `StoreState::retire`:251–258 | M15 deletion; narrowing variant changes eviction boundary from 64 to 65 |
| terminal-path-owner-gates-unguarded (repeat-of rev1 owner-gate) | New `completion_receipt_terminal_history_refuses_foreign_owners_and_repeat_cancellation`: Sampled, InlineResult, Cancelled × foreign thread/generation/call × all seven entry points; forged foreign leases originate from a real lease. Legitimate status stays unchanged | `terminal_error`:243–248, `cancel`:505, terminal `status`:525; callers `publish_exit`:375, `resolve_initial_response`:302, `lease_for_sampling`:404, `fail_sampling`:441, `acknowledge_sampled`:464 | M12/M13/M14; narrower variants bypass only mismatching runtime generation |
| terminal-history-paths-untested | The same table-driven terminal-history test asserts own-owner cancel returns AlreadyTerminal for each terminal outcome, then checks the outcome was preserved | `cancel`:502–506 | Change terminal cancellation to Ok or raw terminal error; narrower variant admits repeated cancellation only for Sampled |
| owner-call-id-boundary-256 | New `completion_receipt_owner_accepts_256_bytes_and_refuses_257`: accepted 256-byte owner reserves through the store; 257 bytes returns InvalidOwner. Existing empty-id refusal kept | `ReceiptOwner::new`:34–41, `reserve`:274 | Change `>` to `>=` at :40 |
| sampling-source-attribution-nondeterministic | Updated `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease`: deterministic LeasedToSampling and Sampled statuses both name TerminalStdinOutput. Existing `completion_receipt_happy_path_samples_exactly_once` deterministically asserts both PushedCompletion statuses | `lease_for_sampling`:404–432, `acknowledge_sampled`:464–487, `status`:515 | M16, hard-code PushedCompletion in lease record |

## AC coverage map

**6 of 6 AC rows have driving and refusal tests through the production receipt API. Execution on this revised test tree: 0 of 6 AC rows driven in this local run.** The latest brief explicitly delegates core test execution to hosted relux-ci after handoff; Clippy type-checking is not reported as test execution. The inactive module has no exec/tool call sites yet, as required by this leaf.

| AC | Driving test | Refusal test | Production entry points |
|---|---|---|---|
| 1 | `completion_receipt_happy_path_samples_exactly_once` | `completion_receipt_rejects_a_second_claim_after_sampling` | reserve:274 → resolve_initial_response:302 → publish_exit:375 → lease_for_sampling:404 → acknowledge_sampled:464 |
| 2 | `completion_receipt_exit_and_initial_response_are_linearized_in_both_orders` (barriers force exit-first inline, exit-first arm, and arm-first) | `completion_receipt_inline_decision_waits_for_finalized_exit`; inline leasing refusal in the order test; `completion_receipt_duplicate_exit_while_reserved_preserves_first_completion` | publish_exit:375, resolve_initial_response:302, lease_for_sampling:404 |
| 3 | `completion_receipt_failed_lease_requeues_same_receipt_and_rejects_stale_token` | `completion_receipt_stale_failed_lease_cannot_requeue_a_new_lease` | fail_sampling:441, lease_for_sampling:404, acknowledge_sampled:464 |
| 4 | `completion_receipt_cancellation_is_terminal_from_each_unsampled_state` | Cancelled leasing/acknowledgment refusal within that test; new terminal repeat-cancellation table | cancel:492, status:515, lease_for_sampling:404, acknowledge_sampled:464, reserve:274 |
| 5 | `completion_receipt_capacity_refuses_the_65th_and_reuses_a_freed_slot`; new terminal-history eviction and call-id boundary tests | Structured CapacityExceeded at reservation 65; UnknownReceipt for evicted terminal id; InvalidOwner at 257 bytes | reserve:274, cancel:492, status:515, ReceiptOwner::new:34 |
| 6 | `completion_receipt_terminal_stdin_and_pushed_claim_race_consumes_once`; `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease`; happy path for deterministic pushed attribution | AlreadyLeased/AlreadyConsumed assertions in both shared-claim tests | lease_for_sampling:404, fail_sampling:441, acknowledge_sampled:464, status:515 |

Surface-table map, using the supplied single row:

| Surface row | Attacking tests | Killed narrowing mutants | Out-of-contract inputs (AC clause) |
|---|---|---|---|
| concurrency state machine | All 20 named completion_receipt tests; specifically the three new regression tests and the strengthened deterministic stdin test above | Current-tree mutant execution is unverified under the fast-lane prohibition. Historical rev2 evidence records M1/M2/M4/M5/M6/M7/M9/M10/M11 failures; tests changed, so that is not reused as a current-tree gate pass. New and narrowing mutant recipes are mapped below for execution by hosted validation/review | none within the receipt-state-machine surface; exec launch, watchers, mailbox, transport, model wake, and host integration are outside this leaf per Description “Not wired to tools or the mailbox yet” and Scope “no watcher/process-manager hooks” |

## Mutant evidence and bounds

No mutant was applied to the candidate. **0 new mutant executions; 0 observed kills on the revised test tree.** No failing test or exit code is invented. These are expected killing tests, not measured kills or survivors. A mutant is not a survivor unless it was actually executed green. The latest revision-5 brief forbids local codex-core test runs and delegates them to hosted CI; this supersedes the old local mutant-run instruction.

| Mutant | What it narrows the gate to | Named expected failing test | Actual execution / bound |
|---|---|---|---|
| M12: remove terminal_error owner comparison | Terminal-history operation errors no longer hide outcomes from foreign owners | `completion_receipt_terminal_history_refuses_foreign_owners_and_repeat_cancellation` | Not run; foreign thread/generation/call terminal refusals unverified at runtime |
| M13: remove terminal status owner comparison | Retained terminal status becomes visible to foreign owners | Same terminal-history test | Not run; terminal status privacy unverified at runtime |
| M14: map terminal cancel ForeignOwner to AlreadyTerminal | Foreign cancellation reveals that a terminal receipt exists | Same terminal-history test | Not run; foreign cancellation precedence unverified at runtime |
| M15: delete pop_front | History never evicts | `completion_receipt_terminal_history_evicts_only_the_oldest_after_64_outcomes` | Not run; deletion recipe from review, supplemented by narrowing recipe below |
| M15 narrowing: change eviction condition to `self.terminal.len() == MAX_TERMINAL_RECEIPTS + 1` | Retains 65 outcomes rather than 64, preserving eviction and all shorter histories | Same eviction test | Not run; 64/65 retention boundary unverified at runtime |
| M12/M13 narrowing: keep owner comparison but exempt an owner with the same thread and call (different generation) | Thread/call gates remain; exactly the generation-mismatch class bypasses terminal checks | Same terminal-history test | Not run; repeated generation-gate class unverified at runtime |
| M14 narrowing: preserve ForeignOwner except for a foreign generation matching thread/call, return AlreadyTerminal | Only generation-mismatched terminal cancellation leaks terminal existence | Same terminal-history test | Not run; generation cancellation gate unverified at runtime |
| Own terminal cancel narrowing: return Ok only when terminal error is AlreadyConsumed | Repeated cancellation is admitted only for Sampled, retaining InlineResult/Cancelled refusal | Same terminal-history test | Not run; own-terminal refusal unverified at runtime |
| Call-id boundary `>` → `>=` | Accepts only 1..255 bytes, incorrectly refusing valid 256-byte input | `completion_receipt_owner_accepts_256_bytes_and_refuses_257` | Not run; boundary acceptance unverified at runtime |
| M16: record PushedCompletion regardless of source at :424 | Stdin may win, but its lease records the pushed source | `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease` | Not run; deterministic attribution unverified at runtime |

Prior F1–F3 tests are retained: `completion_receipt_foreign_owner_is_refused_on_resolve_and_lease` (M1/M2), `completion_receipt_foreign_lease_is_refused_on_fail_and_acknowledge` (M10/M11), `completion_receipt_stale_failed_lease_cannot_requeue_a_new_lease` (M4), and `completion_receipt_duplicate_exit_while_reserved_preserves_first_completion` (M7). Historical execution evidence is in the existing revision-2 validation archive. Revision-4 hosted run 36981512463 passed all lanes and 17 tests on tree e9a8095f; its test-tree identity differs from this revision and is not a pass for the added tests.

## Validation in this run

Local target: macOS native Rust, toolchain 1.95.0; Codex supports macOS/Linux/Windows. No Apple app target is applicable. No build environment overrides were set. From codex-rs, only the prescribed NEXTEST_TEST_THREADS=4, INSTA_UPDATE=no and INSTA_WORKSPACE_ROOT=$PWD were exported.

| Command | Real exit | Evidence / result |
|---|---:|---|
| `python3 /Users/iv/Developer/IV/codex/.temp/goal-token-burn/impl/codex-fix-suite-busy.py --any` (entry) | 0 | busy-01.log: FREE |
| `/Users/iv/Developer/IV/codex/.temp/goal-token-burn/impl/codex-target-guard.sh` | 0 | target-guard-01.log: workspace-member artifacts cleaned |
| `just fmt` from codex-rs | 0 | fmt-01.log |
| `just clippy -p codex-core` from codex-rs | 0 | clippy-01.log: dev profile finished, tests type-checked; three baseline unused-import warnings in restored out-of-scope files, no receipt warning |
| `git diff --check` | 0 | diff-check-01.log |
| Revision-4 patch comparison / test-name preservation | 0 | product unchanged; 17 of 17 previous test names retained; 20 total tests; +167/-0 rework test lines |

Not run: `just test -p codex-core -E 'test(completion_receipt)'`, core/app-server suites, and behavioral mutant suites, per the latest producer/rework brief. Hosted relux-ci executes the 20 receipt tests on the exact published candidate after handoff. No current test-green checklist assertion is based on Clippy. `just fix` is not rerun in this tests-only rework: revision 5 requests fmt/clippy, and its previous incidental baseline edits have been explicitly restored. No background process is left running.

## Outcome-scoped logbook

- Revision-4 robustness findings are test gaps; product bytes unchanged. The full five-finding set was addressed together, including the repeated owner-gate class.
- All original tests remain under their original names. Terminal foreign-owner tests attack every receipt entry point and preserve the real owner's view after each attack.
- Terminal history bound is attacked in both directions: evict oldest after 65 retirements, retain every one of the latest 64. Slot reservations are released on each iteration.
- Restoring the three upstream-baseline imports makes their warnings visible again; retaining those imports is the explicit upstream-PR scope decision, not a receipt lint regression.
- New runtime claims remain unverified pending hosted CI. Previous greens and predicted mutant kills are deliberately not reported as current execution.
- Research/check artifacts stay in the worktree's ignored .temp/TASK-260929-u2i5rr; this outcome and validation archive are prepared outside the managed worktree and attached only through task-board APIs. No direct board files were edited.

The authoritative busy check will be run once immediately before handoff. FREE routes to `task-board handoff TASK-260929-u2i5rr --role developer`; BUSY routes to the prescribed HOLD-BUILD note. The board's fast local landing gate runs at publication; hosted CI and reviewer mutant execution provide the remaining behavioral evidence.
