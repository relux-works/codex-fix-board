# Developer handoff — TASK-260929-u2i5rr receipt-state-machine

## Summary

Implemented an inactive in-memory state machine for opted-in background exec completion receipts. A single mutex linearizes initial-response decisions, finalized exit publication, lease acquisition, sampling acknowledgment, and cancellation. Each opaque receipt is bound to thread ID, runtime generation, and a bounded call ID. The receipt pool caps active reservations at 64 and returns a structured capacity error. Pushed completion and terminal stdin output arbitrate through one lease; lease failure requeues the same receipt, while acknowledgment retires it as Sampled and frees the slot.

The candidate remains uncommitted on the Story worktree. No tool, mailbox, watcher, process-manager, or model-facing integration was added.

## Changed files

- `codex-rs/core/src/unified_exec/completion_receipt.rs` — 465 nonblank, noncomment production lines, under the 500 LoC limit.
- `codex-rs/core/src/unified_exec/completion_receipt_tests.rs` — 13 named receipt tests.
- `codex-rs/core/src/unified_exec/mod.rs` — crate-visible module export only.

At the Story checkpoint neither new receipt path existed, so there were no earlier committed reviewer tests in this leaf to remove or rename. All 13 tests are additive.

## Acceptance criteria coverage

Coverage ratio: **6 of 6 AC rows driven**, through named `CompletionReceiptStore` production API entry points. Each row also has refusal coverage.

| AC | Driving test and production entry | Refusal test and production entry | Result |
|---|---|---|---|
| 1. Reserved → Armed → Queued → LeasedToSampling → Sampled exposes one sampled claim | `completion_receipt_happy_path_samples_exactly_once` drives `reserve`, `resolve_initial_response`, `publish_exit`, `lease_for_sampling`, and `acknowledge_sampled` | `completion_receipt_rejects_a_second_claim_after_sampling` retries `lease_for_sampling` after Sampled and expects `AlreadyConsumed` | Green |
| 2. Exit and initial-response decision rendezvous without loss or duplication | `completion_receipt_exit_and_initial_response_are_linearized_in_both_orders` uses barriers for exit-before-inline, exit-before-Arm, and Arm-before-exit | Same test verifies InlineResult cannot be leased for a pushed completion | Green |
| 3. Lease failure requeues the same receipt without duplication | `completion_receipt_failed_lease_requeues_same_receipt_and_rejects_stale_token` drives `fail_sampling`, then re-leases and samples the same ID | Same test sends the prior lease to `acknowledge_sampled` and expects `StaleLease` | Green |
| 4. Cancellation from every unsampled state is terminal and frees capacity | `completion_receipt_cancellation_is_terminal_from_each_unsampled_state` cancels Reserved, Armed, Queued, and Leased records | Same test verifies cancelled records cannot lease or acknowledge and that `reserve` succeeds afterward | Green |
| 5. Capacity is 64, N+1 refusal is structured, and a released slot is reusable | `completion_receipt_capacity_refuses_the_65th_and_reuses_a_freed_slot` reserves 64, refuses the 65th, cancels one, and reserves again | Same test expects `CapacityExceeded { capacity: 64 }` from `reserve` at N+1 | Green |
| 6. Pushed and terminal-stdin claims share one consumed claim | `completion_receipt_terminal_stdin_and_pushed_claim_race_consumes_once` races both sources; only one samples | `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease` verifies the other source gets `AlreadyLeased`; after the winning source samples, another claim gets `AlreadyConsumed` | Green |

The separate surface-row map is attached as `TASK-260929-u2i5rr_coverage-map.md`.

## Mutant evidence

Ten distinct narrowing mutants were tried. The final 13-test suite kills all ten; the intermediate race-only filter survived the cross-source mutant, with the stated bound below, and prompted the deterministic refusal test. Every surviving mutant result is explicitly reported with that bound. No mutant was accepted based only on deleting a gate or checking source text.

| Mutant | What the weakened gate admits | Named test that failed | Result |
|---|---|---|---|
| Owner equality ignores runtime generation | Same thread/call from a different runtime generation accesses the receipt | `completion_receipt_foreign_runtime_generation_is_refused` | batch 01, exit 100 |
| Capacity changes from `>= 64` to `> 64` | The 65th reservation is admitted | `completion_receipt_capacity_refuses_the_65th_and_reuses_a_freed_slot` | batch 01, exit 100 |
| Duplicate exit publication is accepted from Queued | A second finalized result replaces/reopens the queued result | `completion_receipt_refuses_duplicate_exit_publication` | batch 01, exit 100 |
| InlineResult remains claimable | Inline delivery can also create a pushed sampling claim | `completion_receipt_exit_and_initial_response_are_linearized_in_both_orders` | batch 02, exit 100 |
| Cancellation from Queued is a no-op | A queued receipt remains leaseable after cancellation | `completion_receipt_cancellation_is_terminal_from_each_unsampled_state` | batch 02, exit 100 |
| Acknowledgment ignores lease token while source still matches | A lease from before failure/requeue can acknowledge a later lease | `completion_receipt_failed_lease_requeues_same_receipt_and_rejects_stale_token` | batch 02, exit 100 |
| Sampled terminal receipts can lease again | The same owner obtains a second claim after sampling | `completion_receipt_rejects_a_second_claim_after_sampling` | batch 03, exit 100 |
| Poisoned mutex is unwrapped | Lock poison panics instead of returning `LockPoisoned` | `completion_receipt_poisoned_lock_returns_a_structured_error_after_panic` | batch 03, exit 100 |
| Arm drops an exit retained in Reserved | Exit-before-decision followed by Arm reports Armed and loses the finalized completion | `completion_receipt_exit_and_initial_response_are_linearized_in_both_orders` | batch 04, exit 100 |
| Cross-source second lease is admitted while a first lease is active | Both pushed and terminal-stdin sources can own a lease at once | `completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease` | batch 05 race-only filter: **survived**, exit 0; bound: the concurrent race filter alone did not prove that the competing source was refused before acknowledgment. Added the direct refusal test; batch 06 then failed it, exit 100. |

All mutants ran the behavioral suite with `just test -p codex-core`; none used a static checker as its only harness. There is no source-text gate in this module.

## Validation

Commands ran from `codex-rs/` with the producer-brief environment (`CARGO_TARGET_DIR=/Users/iv/Developer/IV/codex-target`, `CARGO_BUILD_JOBS=4`, `CARGO_INCREMENTAL=0`, the specified `RUSTY_V8_ARCHIVE` and `RUSTY_V8_SRC_BINDING_PATH`, `NEXTEST_TEST_THREADS=4`, `INSTA_UPDATE=no`).

| Command | Result | Log |
|---|---|---|
| `just test -p codex-core -E 'test(completion_receipt)'` on final candidate | exit 0; 13 passed, 4,881 skipped | `.temp/TASK-260929-u2i5rr/test-05.log` |
| `just test -p codex-core -E 'test(completion_receipt_capacity_refuses) | test(completion_receipt_foreign_runtime_generation) | test(completion_receipt_refuses_duplicate_exit)'` with batch 01 mutants | expected exit 100; all 3 named tests failed | `.temp/TASK-260929-u2i5rr/mutant-batch-01.log` |
| `just test -p codex-core -E 'test(completion_receipt_cancellation_is_terminal) | test(completion_receipt_failed_lease_requeues) | test(completion_receipt_exit_and_initial_response_are_linearized)'` with batch 02 mutants | expected exit 100; all 3 named tests failed | `.temp/TASK-260929-u2i5rr/mutant-batch-02.log` |
| `just test -p codex-core -E 'test(completion_receipt_rejects_a_second_claim_after_sampling) | test(completion_receipt_poisoned_lock_returns_a_structured_error_after_panic)'` with batch 03 mutants | expected exit 100; both named tests failed | `.temp/TASK-260929-u2i5rr/mutant-batch-03.log` |
| `just test -p codex-core -E 'test(completion_receipt_exit_and_initial_response_are_linearized_in_both_orders)'` with batch 04 mutant | expected exit 100; named race test failed | `.temp/TASK-260929-u2i5rr/mutant-batch-04.log` |
| `just test -p codex-core -E 'test(completion_receipt_terminal_stdin_and_pushed_claim_race_consumes_once)'` with batch 05 cross-source mutant | exit 0; race test passed under mutant, recorded as a survivor of this filter and diagnostic bound | `.temp/TASK-260929-u2i5rr/mutant-batch-05.log` |
| `just test -p codex-core -E 'test(completion_receipt_terminal_stdin_and_pushed_sources_share_one_lease) | test(completion_receipt_terminal_stdin_and_pushed_claim_race_consumes_once)'` with batch 06 same mutant | expected exit 100; direct refusal test failed, race test passed | `.temp/TASK-260929-u2i5rr/mutant-batch-06.log` |
| `just fix -p codex-core` on final 13-test candidate | exit 0 | `.temp/TASK-260929-u2i5rr/fix-final-02.log` |
| `just fmt` after restoring out-of-scope lines | exit 0 | `.temp/TASK-260929-u2i5rr/fmt-final-03.log` |
| `git diff --check` after final formatting | exit 0 | command output in run transcript |

The final filtered test compiled `codex-core` and the related test binaries, so it also supplies the relevant build validation. No separate `just build` or full suite was run. Tests were not rerun after the final format/lint commands, following the repository instruction. The final formatter made no content change to the receipt files; `just fix` changed no receipt files.

One batch 03 log-wrapper attempt assigned to zsh's read-only `status` variable and returned shell exit 1 after the test invocation. The same batch 03 filter was rerun with a safe `gate_rc` variable; the corrected run is the recorded batch 03 evidence and returned exit 100. No gate result is inferred from the wrapper attempt.

`just fix` removed three existing unused imports outside this task's scope in `core/src/tools/registry.rs`, `core/tests/suite/openai_file_mcp.rs`, and `core/tests/suite/scenarios.rs`. Those exact lines were restored after lint. The final working-tree diff contains only the three declared files. Existing unrelated unused-import warnings therefore remain outside this leaf.

Validation logs are attached in `TASK-260929-u2i5rr_validation-logs.tar.gz`; it contains the exact test, mutant, format, fix, and tool-readiness logs referenced above.

## Out-of-contract rows and stated bounds

- Actual exec launch integration and suppression of process launch when `reserve` returns `CapacityExceeded` are not exercised here. The task description says: “Not wired to tools or the mailbox yet (sibling leaf B2 and later stories).” This module returns the structured refusal before its caller may launch; it contains no launcher call site.
- Mailbox delivery, final sampling-request submission, and transport acknowledgment are not exercised here. The task description says this leaf is “Not wired to tools or the mailbox yet.” Tests acknowledge by directly calling `acknowledge_sampled` after a synthetic lease.
- Watcher and process-manager hooks are excluded by the Scope clause: “no watcher/process-manager hooks (sibling leaf B2).” Exit publication is tested directly through `publish_exit`; no OS process runs.
- Process-output bytes, retention/truncation, and model-visible fragments are outside this state-only leaf: Scope limits changes to the receipt module, sibling tests, and module export, and AC rows 1–6 do not specify output payload retention.
- The bounded terminal history retains only the latest 64 terminal outcomes for status/error reporting. It does not evict active receipts or active slot reservations.
- Host persistence/restart and remote/cross-platform execution are not exercised; this stage stores live in-memory state only.

## Logbook

- The receipt mutex is the single linearization point. An exit retained in Reserved becomes either InlineResult or Queued when the initial response decision commits.
- Pushed completion and terminal stdin share one lease/token; failed sampling requeues the same receipt, and sampled acknowledgment frees capacity.
- Cross-source lease mutation initially survived the race-only filter; the bound was that the filter did not force/refuse a second active lease before sampling. The deterministic refusal test then killed the same mutant.
- `just fix` tried unrelated unused-import cleanup in three neighboring files; the changes were restored so the candidate stays inside the declared scope.
- The candidate is uncommitted in the managed Story worktree for handoff snapshotting.
