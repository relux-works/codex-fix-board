# TASK-260929-u2i5rr validation log index

Commands ran in the Story worktree unless stated otherwise. The focused candidate suite was run before `just fmt` and `just fix -p codex-core`; no candidate test suite was rerun afterward.

| Log | Command | Exit | Meaning |
|---|---|---:|---|
| `target-guard-01.log` | `/Users/iv/Developer/IV/codex/.temp/goal-token-burn/impl/codex-target-guard.sh` | 0 | Shared Cargo target prepared for this checkout |
| `core-tests-01.log` | `NEXTEST_TEST_THREADS=4 INSTA_UPDATE=no INSTA_WORKSPACE_ROOT="$PWD" just test -p codex-core -E 'test(completion_receipt)'` from `codex-rs/` | 0 | 17 receipt tests passed; 4881 tests skipped |
| `fmt-01.log` | `just fmt` from `codex-rs/` | 0 | Formatting pass |
| `fix-01.log` | `just fix -p codex-core` from `codex-rs/` | 0 | Clippy/fix pass; 4m19s |
| `mutant-M1-lease-owner.log` | `cargo test --offline` in the isolated mutant harness | 101 | Expected red; M1 killed by foreign-owner regression test |
| `mutant-M2-resolve-owner.log` | same | 101 | Expected red; M2 killed by foreign-owner regression test |
| `mutant-M4-fail-token.log` | same | 101 | Expected red; M4 killed by stale failed-lease test |
| `mutant-M5-ack-token.log` | same | 101 | Expected red; M5 killed by stale acknowledge test |
| `mutant-M6-double-lease.log` | same | 101 | Expected red; M6 killed by shared-source claim test |
| `mutant-M7-reserved-publish.log` | same | 101 | Expected red; M7 killed by duplicate Reserved exit test |
| `mutant-M9-capacity.log` | same | 101 | Expected red; M9 killed by capacity test |
| `mutant-M10-fail-owner.log` | same | 101 | Expected red; M10 killed by foreign-lease test |
| `mutant-M11-ack-owner.log` | same | 101 | Expected red; M11 killed by foreign-lease test |

The scratch harness is `/Users/iv/Developer/IV/codex/.temp/TASK-260929-u2i5rr-mutants`. Its source copy was restored to the candidate after the mutations. Both source and test files compare byte-for-byte equal to the candidate after format/lint.

The first scratch `cargo test --offline` attempt, before copying the worktree lockfile, exited 101 during dependency resolution because offline Cargo could not select yanked `spin 0.9.8`; no tests ran in that attempt. After copying `codex-rs/Cargo.lock`, all mutant runs compiled and failed only at the named regression test.
